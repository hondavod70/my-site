export const isEscapeKey = (evt) => evt.key === 'Escape';
export const isArrowUpKey = (evt) => evt.key === 'ArrowUp';
export const isArrowDownKey = (evt) => evt.key === 'ArrowDown';
export const isArrowLeftKey = (evt) => evt.key === 'ArrowLeft';
export const isArrowRightKey = (evt) => evt.key === 'ArrowRight';
