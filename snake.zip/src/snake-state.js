import { sideSize } from './config';
import { getRandomInteger } from './utils';

export const snakeState = {
  direct: 'start',
  startPosition: 1,
  size: 1,
  headPosition: null,
  tailPosition: null,
  trace: [],
  foodPosition: null,
  timeout: 300,
};

export const setSnakeStatePosition = (direct) => {
  if (direct === 'start') {
    snakeState.headPosition = snakeState.startPosition + snakeState.size - 1;
    snakeState.tailPosition = snakeState.startPosition;
  } else if (direct === 'right') {
    snakeState.headPosition++;
  } else if (direct === 'left') {
    snakeState.headPosition--;
  } else if (direct === 'up') {
    snakeState.headPosition -= sideSize;
  } else if (direct === 'down') {
    snakeState.headPosition += sideSize;
  }
  snakeState.tailPosition = snakeState.trace[snakeState.trace.length - 1];
  snakeState.trace.unshift(snakeState.headPosition);
  console.log(snakeState.trace);
};

export const setSnakeStateFoodPosition = (min, max) => {
  snakeState.foodPosition = getRandomInteger(min, max);
};
