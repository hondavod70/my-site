const boxSize = 25;
const delta = 6;
export const sideSize = 30;
export const fieldArea = Math.pow(sideSize, 2);
export const fieldWidth = sideSize * boxSize + delta;
