import {
  isArrowDownKey,
  isArrowLeftKey,
  isArrowRightKey,
  isArrowUpKey,
  isEscapeKey,
} from './utils.js';

const boxTemplateElement = document.querySelector('#box-template').content;
const mainElement = document.querySelector('.main');
const canvasContainerElement = document.querySelector('.canvas');
const documentFragment = document.createDocumentFragment();
const rows = 30;
const cols = rows;
const boxCount = rows * cols;
const boxSize = 25;
const mainWdth = cols * boxSize + 6;
const timeout = 300;
const state = {
  direct: 'stop',
  posX: 1,
  posY: 1,
  count: 1,
};
let timeoutHandler;

const myLoop = (direct) => {
  if (state.direct === 'stop') {
    return;
  }

  timeoutHandler = setTimeout(() => {
    //state.count++;
    console.log(state.count, state.direct);
    if (direct === 'right') {
      console.log(state.count);
      document.getElementById(++state.count).classList.add('marked');
    } else if (direct === 'left') {
      document.getElementById(--state.count).classList.add('marked');
    } else if (direct === 'up') {
      document.getElementById((state.count -= cols)).classList.add('marked');
    } else if (direct === 'down') {
      document.getElementById((state.count += cols)).classList.add('marked');
    }
    if (state.count < boxCount) {
      myLoop(state.direct);
    }
  }, timeout);
};

for (let i = 1; i <= boxCount; i++) {
  const newBoxElement = boxTemplateElement.cloneNode(true);
  const newBoxDiv = newBoxElement.querySelector('div');
  newBoxDiv.id = `${i}`;
  documentFragment.appendChild(newBoxElement);
}

mainElement.style.width = `${mainWdth}px`;
canvasContainerElement.appendChild(documentFragment);
document.getElementById(state.count).classList.add('marked');

const onDocumentKeydown = async (evt) => {
  //evt.preventDefault();
  if (isArrowRightKey(evt)) {
    clearTimeout(timeoutHandler);
    state.direct = 'right';
  } else if (isArrowLeftKey(evt)) {
    clearTimeout(timeoutHandler);
    state.direct = 'left';
  } else if (isArrowUpKey(evt)) {
    clearTimeout(timeoutHandler);
    state.direct = 'up';
  } else if (isArrowDownKey(evt)) {
    clearTimeout(timeoutHandler);
    state.direct = 'down';
  } else if (isEscapeKey(evt)) {
    state.direct = 'stop';
  } else {
    return;
  }
  myLoop(state.direct);
};

document.addEventListener('keydown', onDocumentKeydown, true);
