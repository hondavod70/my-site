export const boxTemplateElement =
  document.querySelector('#box-template').content;
export const mainElement = document.querySelector('.main');
export const canvasContainerElement = document.querySelector('.canvas');
export const documentFragment = document.createDocumentFragment();
