import {
  isArrowDownKey,
  isArrowLeftKey,
  isArrowRightKey,
  isArrowUpKey,
  isEscapeKey,
} from './utils.js';

import { fieldArea, fieldWidth } from './config.js';
import {
  boxTemplateElement,
  canvasContainerElement,
  documentFragment,
  mainElement,
} from './dom-elements.js';
import {
  setSnakeStateFoodPosition,
  setSnakeStatePosition,
  snakeState,
} from './snake-state.js';

let timeoutHandler;

const myLoop = (direct) => {
  if (direct === 'stop') {
    return;
  }
  timeoutHandler = setTimeout(() => {
    /*
		console.log(
      snakeState.headPosition,
      snakeState.tailPosition,
      snakeState.direct
    );
		*/

    setSnakeStatePosition(snakeState.direct);
    document.getElementById(snakeState.tailPosition).classList.remove('marked');
    document.getElementById(snakeState.headPosition).classList.add('marked');
    if (snakeState.headPosition === snakeState.foodPosition) {
      snakeState.size++;
      snakeState.timeout = snakeState.timeout - 100 / snakeState.size;
      document
        .getElementById(snakeState.foodPosition)
        .classList.remove('marked-food');
      setSnakeStateFoodPosition(1, fieldArea);
      document
        .getElementById(snakeState.foodPosition)
        .classList.add('marked-food');
    } else {
      snakeState.trace.pop(snakeState.tailPosition);
    }

    if (snakeState.headPosition <= fieldArea) {
      myLoop(snakeState.direct);
    }
  }, snakeState.timeout);
};

for (let i = 1; i <= fieldArea; i++) {
  const newBoxElement = boxTemplateElement.cloneNode(true);
  const newBoxDiv = newBoxElement.querySelector('div');
  newBoxDiv.id = `${i}`;
  documentFragment.appendChild(newBoxElement);
}

mainElement.style.width = `${fieldWidth}px`;
canvasContainerElement.appendChild(documentFragment);
setSnakeStatePosition(snakeState.direct);
setSnakeStateFoodPosition(1, fieldArea);
document.getElementById(snakeState.headPosition).classList.add('marked');
document.getElementById(snakeState.foodPosition).classList.add('marked-food');
//document.getElementById(snakeState.tailPosition).classList.add('marked');

const onDocumentKeydown = async (evt) => {
  //evt.preventDefault();
  if (isArrowRightKey(evt)) {
    if (snakeState.direct === 'left') {
      return;
    }
    clearTimeout(timeoutHandler);
    snakeState.direct = 'right';
  } else if (isArrowLeftKey(evt)) {
    if (snakeState.direct === 'right') {
      return;
    }
    clearTimeout(timeoutHandler);
    snakeState.direct = 'left';
  } else if (isArrowUpKey(evt)) {
    if (snakeState.direct === 'down') {
      return;
    }
    clearTimeout(timeoutHandler);
    snakeState.direct = 'up';
  } else if (isArrowDownKey(evt)) {
    if (snakeState.direct === 'up') {
      return;
    }
    clearTimeout(timeoutHandler);
    snakeState.direct = 'down';
  } else if (isEscapeKey(evt)) {
    snakeState.direct = 'stop';
    return;
  } else {
    return;
  }
  myLoop(snakeState.direct);
};

document.addEventListener('keydown', onDocumentKeydown, true);
