export const isEscapeKey = (evt) => evt.key === 'Escape';
export const isArrowUpKey = (evt) => evt.key === 'ArrowUp';
export const isArrowDownKey = (evt) => evt.key === 'ArrowDown';
export const isArrowLeftKey = (evt) => evt.key === 'ArrowLeft';
export const isArrowRightKey = (evt) => evt.key === 'ArrowRight';

export const getRandomInteger = (min, max) => {
  const lower = Math.ceil(Math.min(min, max));
  const upper = Math.floor(Math.max(min, max));
  const result = Math.random() * (upper - lower + 1) + lower;
  return Math.floor(result);
};
